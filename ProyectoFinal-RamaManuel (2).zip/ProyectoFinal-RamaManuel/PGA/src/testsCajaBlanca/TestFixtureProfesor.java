package testsCajaBlanca;


public class TestFixtureProfesor
{
    public TestFixtureProfesor()
    {
        super();
    }
    
    public void setUp() throws Exception
    {
        
    }
    
    public void tearDown() throws Exception
    {
        
    }
}
